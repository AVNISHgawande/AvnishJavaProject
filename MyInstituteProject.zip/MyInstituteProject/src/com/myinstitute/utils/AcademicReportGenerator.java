package com.myinstitute.utils;

import com.myinstitute.records.Learner;
import com.myinstitute.records.Registration;

public class AcademicReportGenerator {
    
    public static String generateReport(Learner learner) {
        StringBuilder report = new StringBuilder();
        
        report.append("OFFICIAL ACADEMIC REPORT\n");
        report.append("=========================\n");
        report.append("Learner ID: ").append(learner.getIdentifier()).append("\n");
        report.append("Name: ").append(learner.getGivenName()).append("\n");
        report.append("Enrollment ID: ").append(learner.getEnrollmentId()).append("\n");
        report.append("Email: ").append(learner.getContactEmail()).append("\n");
        report.append("Status: ").append(learner.getStanding()).append("\n");
        report.append("\n");
        
        report.append("MODULE HISTORY\n");
        report.append("==============\n");
        
        if (learner.getRegisteredModules().isEmpty()) {
            report.append("No modules registered.\n");
        } else {
            // Header
            report.append(String.format("%-10s %-30s %-8s %-6s %-10s\n", 
                    "Code", "Module", "Units", "Assessment", "Points"));
            report.append(String.format("%-10s %-30s %-8s %-6s %-10s\n", 
                    "----------", "------------------------------", "--------", "----------", "----------"));
            
            // Modules
            double totalPoints = 0;
            int totalUnits = 0;
            
            for (Registration registration : learner.getRegisteredModules()) {
                String code = registration.getModule().getCode();
                String title = registration.getModule().getTitle();
                int units = registration.getModule().getUnits();
                String assessment = registration.getAssessment() != null ? registration.getAssessment().name() : "N/A";
                double points = registration.getAssessment() != null ? registration.getAssessment().getPoints() : 0;
                
                report.append(String.format("%-10s %-30s %-8d %-6s %-10.2f\n", 
                        code, title, units, assessment, points));
                
                if (registration.getAssessment() != null) {
                    totalPoints += points * units;
                    totalUnits += units;
                }
            }
            
            // GPA calculation
            if (totalUnits > 0) {
                double gpa = totalPoints / totalUnits;
                report.append("\n");
                report.append(String.format("Cumulative GPA: %.2f\n", gpa));
                report.append(String.format("Total Units: %d\n", totalUnits));
            }
        }
        
        return report.toString();
    }
}