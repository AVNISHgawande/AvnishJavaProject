package com.myinstitute.services;

import com.myinstitute.records.Module;
import com.myinstitute.records.Term;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ModuleService {
    private final List<Module> modules;
    
    public ModuleService() {
        this.modules = new ArrayList<>();
    }
    
    public void addModule(Module module) {
        modules.add(module);
    }
    
    public List<Module> listModules() {
        return new ArrayList<>(modules);
    }
    
    public Optional<Module> findModuleByCode(String code) {
        return modules.stream()
                .filter(m -> m.getCode().equals(code))
                .findFirst();
    }
    
    public void updateModule(String code, String title, int units, String instructor, 
                            Term term, String department) {
        findModuleByCode(code).ifPresent(module -> {
            // You'll need to add setters to your Module.java class for this to work
        });
    }
    
    public void deactivateModule(String code) {
        findModuleByCode(code).ifPresent(module -> module.setStanding("INACTIVE"));
    }
    
    public List<Module> searchModulesByInstructor(String instructor) {
        return modules.stream()
                .filter(m -> m.getInstructor().equalsIgnoreCase(instructor))
                .collect(Collectors.toList());
    }
    
    public List<Module> searchModulesByDepartment(String department) {
        return modules.stream()
                .filter(m -> m.getDepartment().equalsIgnoreCase(department))
                .collect(Collectors.toList());
    }
    
    public List<Module> searchModulesByTerm(Term term) {
        return modules.stream()
                .filter(m -> m.getTerm() == term)
                .collect(Collectors.toList());
    }
}