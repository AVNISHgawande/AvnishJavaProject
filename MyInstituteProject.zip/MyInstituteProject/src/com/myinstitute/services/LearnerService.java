package com.myinstitute.services;

import com.myinstitute.exceptions.DuplicateRegistrationException;
import com.myinstitute.exceptions.MaxUnitLimitExceededException;
import com.myinstitute.records.Learner;
import com.myinstitute.records.Module;
import com.myinstitute.records.Registration;
import com.myinstitute.utils.AcademicReportGenerator;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class LearnerService {
    private final List<Learner> learners;
    
    public LearnerService() {
        this.learners = new ArrayList<>();
    }
    
    public void addLearner(Learner learner) {
        learners.add(learner);
    }
    
    public List<Learner> listLearners() {
        return new ArrayList<>(learners);
    }
    
    public Optional<Learner> findLearnerByIdentifier(String identifier) {
        return learners.stream()
                .filter(l -> l.getIdentifier().equals(identifier))
                .findFirst();
    }
    
    public Optional<Learner> findLearnerByEnrollmentId(String enrollmentId) {
        return learners.stream()
                .filter(l -> l.getEnrollmentId().equals(enrollmentId))
                .findFirst();
    }
    
    public void updateLearner(String identifier, String givenName, String contactEmail) {
        findLearnerByIdentifier(identifier).ifPresent(learner -> {
            learner.setGivenName(givenName);
            learner.setContactEmail(contactEmail);
        });
    }
    
    public void deactivateLearner(String identifier) {
        findLearnerByIdentifier(identifier).ifPresent(learner -> learner.setStanding("INACTIVE"));
    }
    
    public void registerLearnerInModule(String learnerId, Module module) 
            throws DuplicateRegistrationException, MaxUnitLimitExceededException {
        
        Learner learner = findLearnerByIdentifier(learnerId)
                .orElseThrow(() -> new IllegalArgumentException("Learner not found"));
        
        boolean alreadyRegistered = learner.getRegisteredModules().stream()
                .anyMatch(r -> r.getModule().getCode().equals(module.getCode()));
        
        if (alreadyRegistered) {
            throw new DuplicateRegistrationException("Learner is already registered in this module");
        }
        
        int currentUnits = learner.getRegisteredModules().stream()
                .filter(r -> r.getModule().getTerm() == module.getTerm())
                .mapToInt(r -> r.getModule().getUnits())
                .sum();
        
        if (currentUnits + module.getUnits() > 18) {
            throw new MaxUnitLimitExceededException("Unit limit exceeded for this term");
        }
        
        learner.registerForModule(module);
    }
    
    public void deregisterLearnerFromModule(String learnerId, String moduleCode) {
        Learner learner = findLearnerByIdentifier(learnerId)
                .orElseThrow(() -> new IllegalArgumentException("Learner not found"));
        
        learner.getRegisteredModules().removeIf(r -> r.getModule().getCode().equals(moduleCode));
    }

    public Optional<Registration> findRegistration(String learnerId, String moduleCode) {
        return findLearnerByIdentifier(learnerId)
                .flatMap(learner -> learner.getRegisteredModules().stream()
                        .filter(r -> r.getModule().getCode().equals(moduleCode))
                        .findFirst());
    }
    
    public void recordGrade(String learnerId, String moduleCode, double points) {
        findRegistration(learnerId, moduleCode).ifPresent(registration -> registration.recordPoints(points));
    }
    
    public String getAcademicReport(String learnerId) {
        return findLearnerByIdentifier(learnerId)
                .map(learner -> AcademicReportGenerator.generateReport(learner))
                .orElse("Learner not found.");
    }
}