package com.myinstitute.records;

public enum Term {
    SPRING("Spring"), 
    SUMMER("Summer"), 
    FALL("Fall");
    
    private final String displayName;
    
    Term(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
    
    @Override
    public String toString() {
        return displayName;
    }
}