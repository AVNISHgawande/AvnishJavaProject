package com.myinstitute.records;

import java.time.LocalDate;

public abstract class Entity {
    protected String identifier;
    protected String givenName;
    protected String contactEmail;
    protected LocalDate dateCreated;
    
    public Entity(String identifier, String givenName, String contactEmail) {
        this.identifier = identifier;
        this.givenName = givenName;
        this.contactEmail = contactEmail;
        this.dateCreated = LocalDate.now();
    }
    
    // Abstract method to be implemented by subclasses
    public abstract String getProfile();
    
    // Getters and setters with encapsulation
    public String getIdentifier() { return identifier; }
    public void setIdentifier(String identifier) { this.identifier = identifier; }
    
    public String getGivenName() { return givenName; }
    public void setGivenName(String givenName) { this.givenName = givenName; }
    
    public String getContactEmail() { return contactEmail; }
    public void setContactEmail(String contactEmail) { this.contactEmail = contactEmail; }
    
    public LocalDate getDateCreated() { return dateCreated; }
    
    @Override
    public String toString() {
        return "ID: " + identifier + ", Name: " + givenName + ", Email: " + contactEmail;
    }
}