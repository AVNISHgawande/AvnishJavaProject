package com.myinstitute.records;

import java.util.ArrayList;
import java.util.List;

public class Learner extends Entity {
    private String enrollmentId;
    private String standing;
    private final List<Registration> registeredModules;
    
    public Learner(String identifier, String enrollmentId, String givenName, String contactEmail) {
        super(identifier, givenName, contactEmail);
        this.enrollmentId = enrollmentId;
        this.standing = "ACTIVE";
        this.registeredModules = new ArrayList<>();
    }
    
    @Override
    public String getProfile() {
        return """
                Learner Profile:
                ID: """ + identifier + "\n" +
                "Enrollment ID: " + enrollmentId + "\n" +
                "Name: " + givenName + "\n" +
                "Email: " + contactEmail + "\n" +
                "Status: " + standing + "\n" +
                "Registered Modules: " + registeredModules.size();
    }
    
    // Getters and setters
    public String getEnrollmentId() { return enrollmentId; }
    public void setEnrollmentId(String enrollmentId) { this.enrollmentId = enrollmentId; }
    
    public String getStanding() { return standing; }
    public void setStanding(String standing) { this.standing = standing; }
    
    public List<Registration> getRegisteredModules() { return registeredModules; }
    
    public void registerForModule(Module module) {
        Registration registration = new Registration(this, module);
        registeredModules.add(registration);
    }
    
    public void deregisterFromModule(Module module) {
        registeredModules.removeIf(r -> r.getModule().getCode().equals(module.getCode()));
    }
}