package com.myinstitute.records;

public class Module {
    private final String code;
    private final String title;
    private final int units;
    private final String instructor;
    private final Term term;
    private final String department;
    private String standing;
    
    // Using Builder pattern
    private Module(Builder builder) {
        this.code = builder.code;
        this.title = builder.title;
        this.units = builder.units;
        this.instructor = builder.instructor;
        this.term = builder.term;
        this.department = builder.department;
        this.standing = "ACTIVE";
    }
    
    // Builder class
    public static class Builder {
        private String code;
        private String title;
        private int units;
        private String instructor;
        private Term term;
        private String department;
        
        public Builder(String code, String title) {
            this.code = code;
            this.title = title;
        }
        
        public Builder units(int units) {
            this.units = units;
            return this;
        }
        
        public Builder instructor(String instructor) {
            this.instructor = instructor;
            return this;
        }
        
        public Builder term(Term term) {
            this.term = term;
            return this;
        }
        
        public Builder department(String department) {
            this.department = department;
            return this;
        }
        
        public Module build() {
            return new Module(this);
        }
    }
    
    // Getters and setters
    public String getCode() { return code; }
    public String getTitle() { return title; }
    public int getUnits() { return units; }
    public String getInstructor() { return instructor; }
    public Term getTerm() { return term; }
    public String getDepartment() { return department; }
    public String getStanding() { return standing; }
    public void setStanding(String standing) { this.standing = standing; }
    
    @Override
    public String toString() {
        return "Module: " + code + " - " + title + " (" + units + " units)";
    }
}