package com.myinstitute.records;

import java.time.LocalDate;

public class Registration {
    private Learner learner;
    private Module module;
    private LocalDate registrationDate;
    private Double points;
    private Assessment assessment;
    
    public Registration(Learner learner, Module module) {
        this.learner = learner;
        this.module = module;
        this.registrationDate = LocalDate.now();
    }
    
    public void recordPoints(double points) {
        this.points = points;
        this.assessment = Assessment.fromPoints(points);
    }
    
    public double calculateAssessmentPoints() {
        return assessment != null ? assessment.getPoints() : 0.0;
    }
    
    // Getters
    public Learner getLearner() { return learner; }
    public Module getModule() { return module; }
    public LocalDate getRegistrationDate() { return registrationDate; }
    public Double getPoints() { return points; }
    public Assessment getAssessment() { return assessment; }
    
    @Override
    public String toString() {
        return module.getCode() + " - " + module.getTitle() + 
                 (points != null ? " | Points: " + points + " | Assessment: " + assessment : " | Not assessed");
    }
}