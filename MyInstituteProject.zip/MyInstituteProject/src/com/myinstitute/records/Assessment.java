package com.myinstitute.records;

public enum Assessment {
    S(10.0, "Superior"),
    A(9.0, "Excellent"),
    B(8.0, "Good"),
    C(7.0, "Average"),
    D(6.0, "Below Average"),
    E(5.0, "Poor"),
    F(0.0, "Fail");
    
    private final double points;
    private final String description;
    
    Assessment(double points, String description) {
        this.points = points;
        this.description = description;
    }
    
    public double getPoints() {
        return points;
    }
    
    public String getDescription() {
        return description;
    }
    
    public static Assessment fromPoints(double points) {
        if (points >= 90) return S;
        if (points >= 80) return A;
        if (points >= 70) return B;
        if (points >= 60) return C;
        if (points >= 50) return D;
        if (points >= 40) return E;
        return F;
    }
    
    @Override
    public String toString() {
        return name() + " (" + description + ")";
    }
}