package com.myinstitute.data;

import com.myinstitute.records.Module;
import com.myinstitute.records.Term;
import com.myinstitute.records.Learner;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileHandler {
    
    public void exportLearnersToCsv(List<Learner> learners, Path filePath) throws IOException {
        List<String> lines = learners.stream()
                .map(l -> String.join(",",
                    l.getIdentifier(),
                    l.getEnrollmentId(),
                    l.getGivenName(),
                    l.getContactEmail(),
                    l.getStanding(),
                    l.getDateCreated().toString()))
                .collect(Collectors.toList());
        
        lines.add(0, "ID,EnrollmentID,GivenName,Email,Standing,DateCreated");
        Files.write(filePath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    public void exportModulesToCsv(List<Module> modules, Path filePath) throws IOException {
        List<String> lines = modules.stream()
                .map(m -> String.join(",",
                    m.getCode(),
                    m.getTitle(),
                    String.valueOf(m.getUnits()),
                    m.getInstructor(),
                    m.getTerm().name(),
                    m.getDepartment(),
                    m.getStanding()))
                .collect(Collectors.toList());
        
        lines.add(0, "Code,Title,Units,Instructor,Term,Department,Standing");
        Files.write(filePath, lines, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }
    
    public List<Learner> importLearnersFromCsv(Path filePath) throws IOException {
        try (Stream<String> lines = Files.lines(filePath)) {
            return lines.skip(1) // Skip header
                    .map(line -> line.split(","))
                    .filter(parts -> parts.length >= 6)
                    .map(parts -> {
                        Learner learner = new Learner(parts[0], parts[1], parts[2], parts[3]);
                        if (parts.length > 4 && "INACTIVE".equals(parts[4])) {
                            learner.setStanding("INACTIVE");
                        }
                        return learner;
                    })
                    .collect(Collectors.toList());
        }
    }
    
    public List<Module> importModulesFromCsv(Path filePath) throws IOException {
        try (Stream<String> lines = Files.lines(filePath)) {
            return lines.skip(1) // Skip header
                    .map(line -> line.split(","))
                    .filter(parts -> parts.length >= 7)
                    .map(parts -> {
                        try {
                            Term term = Term.valueOf(parts[4]);
                            return new Module.Builder(parts[0], parts[1])
                                    .units(Integer.parseInt(parts[2]))
                                    .instructor(parts[3])
                                    .term(term)
                                    .department(parts[5])
                                    .build();
                        } catch (NumberFormatException e) {
                            System.err.println("Error parsing module: " + String.join(",", parts));
                            return null;
                        }
                    })
                    .filter(module -> module != null)
                    .collect(Collectors.toList());
        }
    }
    
    public Path createBackup(Path sourceDir, Path backupDir) throws IOException {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timestamp = LocalDateTime.now().format(formatter);
        Path backupPath = backupDir.resolve("backup_" + timestamp);
        
        Files.createDirectories(backupPath);
        
        try (Stream<Path> paths = Files.walk(sourceDir)) {
            paths.filter(Files::isRegularFile)
                 .forEach(source -> {
                     try {
                         Path target = backupPath.resolve(sourceDir.relativize(source));
                         Files.createDirectories(target.getParent());
                         Files.copy(source, target);
                     } catch (IOException e) {
                         System.err.println("Error copying file: " + e.getMessage());
                     }
                 });
        }
        
        return backupPath;
    }
    
    public long calculateDirectorySize(Path directory) throws IOException {
        try (Stream<Path> paths = Files.walk(directory)) {
            return paths.filter(Files::isRegularFile)
                         .mapToLong(path -> {
                             try {
                                 return Files.size(path);
                             } catch (IOException e) {
                                 System.err.println("Error getting file size: " + e.getMessage());
                                 return 0L;
                             }
                         })
                         .sum();
        }
    }
    
    public void listFilesByDepth(Path directory, int maxDepth) throws IOException {
        try (Stream<Path> paths = Files.walk(directory, maxDepth)) {
            paths.forEach(path -> {
                try {
                    if (Files.isRegularFile(path)) {
                        System.out.println(path + " - " + Files.size(path) + " bytes");
                    }
                } catch (IOException e) {
                    System.err.println("Error accessing file: " + e.getMessage());
                }
            });
        }
    }
}