package com.myinstitute.core;

import java.nio.file.Path;
import java.nio.file.Paths;

public class AppCore {
    private static AppCore instance;
    private Path dataDirectory;
    
    private AppCore() {
        // Private constructor for singleton
    }
    
    public static AppCore getInstance() {
        if (instance == null) {
            instance = new AppCore();
        }
        return instance;
    }
    
    public void loadConfig() {
        this.dataDirectory = Paths.get("data");
        // Create directory if it doesn't exist
        if (!java.nio.file.Files.exists(dataDirectory)) {
            try {
                java.nio.file.Files.createDirectories(dataDirectory);
            } catch (Exception e) {
                System.err.println("Error creating data directory: " + e.getMessage());
            }
        }
    }
    
    public Path getDataDirectory() {
        return dataDirectory;
    }
}