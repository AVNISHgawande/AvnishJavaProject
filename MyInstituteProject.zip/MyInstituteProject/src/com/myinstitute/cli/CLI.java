package com.myinstitute.cli;

import com.myinstitute.records.Learner;
import com.myinstitute.records.Module;
import com.myinstitute.records.Term;
import com.myinstitute.services.LearnerService;
import com.myinstitute.services.ModuleService;
import com.myinstitute.data.FileHandler;
import com.myinstitute.core.AppCore;
import com.myinstitute.exceptions.DuplicateRegistrationException;
import com.myinstitute.exceptions.MaxUnitLimitExceededException;

import java.io.IOException;
import java.nio.file.Path;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class CLI {
    private final Scanner scanner = new Scanner(System.in);
    private final LearnerService learnerService = new LearnerService();
    private final ModuleService moduleService = new ModuleService();
    private final FileHandler fileHandler = new FileHandler();

    public void start() {
        boolean running = true;
        while (running) {
            printMainMenu();
            try {
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                switch (choice) {
                    case 1:
                        handleLearnerManagement();
                        break;
                    case 2:
                        handleModuleManagement();
                        break;
                    case 3:
                        handleFileOperations();
                        break;
                    case 4:
                        System.out.println("Exiting application. Goodbye!");
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the invalid input from scanner
            }
        }
    }

    private void handleLearnerManagement() {
        boolean managingLearners = true;
        while (managingLearners) {
            printLearnerMenu();
            try {
                int choice = scanner.nextInt();
                scanner.nextLine();
                
                switch (choice) {
                    case 1:
                        addNewLearner();
                        break;
                    case 2:
                        listAllLearners();
                        break;
                    case 3:
                        updateLearner();
                        break;
                    case 4:
                        deactivateLearner();
                        break;
                    case 5:
                        enrollLearnerInModule();
                        break;
                    case 6:
                        manageLearnerGrades();
                        break;
                    case 7:
                        printLearnerReport();
                        break;
                    case 8:
                        managingLearners = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private void handleModuleManagement() {
        boolean managingModules = true;
        while (managingModules) {
            printModuleMenu();
            try {
                int choice = scanner.nextInt();
                scanner.nextLine();
                
                switch (choice) {
                    case 1:
                        addNewModule();
                        break;
                    case 2:
                        listAllModules();
                        break;
                    case 3:
                        updateModule();
                        break;
                    case 4:
                        deactivateModule();
                        break;
                    case 5:
                        searchModules();
                        break;
                    case 6:
                        managingModules = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private void handleFileOperations() {
        boolean handlingFiles = true;
        while (handlingFiles) {
            printFileMenu();
            try {
                int choice = scanner.nextInt();
                scanner.nextLine();
                
                switch (choice) {
                    case 1:
                        importData();
                        break;
                    case 2:
                        exportData();
                        break;
                    case 3:
                        createBackup();
                        break;
                    case 4:
                        listBackupSize();
                        break;
                    case 5:
                        handlingFiles = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();
            }
        }
    }

    private void addNewLearner() {
        System.out.println("\n--- Add New Learner ---");
        System.out.print("Enter identifier (e.g., L001): ");
        String identifier = scanner.nextLine();
        System.out.print("Enter enrollment ID: ");
        String enrollmentId = scanner.nextLine();
        System.out.print("Enter full name: ");
        String fullName = scanner.nextLine();
        System.out.print("Enter contact email: ");
        String email = scanner.nextLine();

        Learner newLearner = new Learner(identifier, enrollmentId, fullName, email);
        learnerService.addLearner(newLearner);
        System.out.println("Learner added successfully!");
    }

    private void listAllLearners() {
        System.out.println("\n--- List All Learners ---");
        learnerService.listLearners().forEach(System.out::println);
    }
    
    private void updateLearner() {
        System.out.println("\n--- Update Learner ---");
        System.out.print("Enter learner identifier to update: ");
        String identifier = scanner.nextLine();
        learnerService.findLearnerByIdentifier(identifier).ifPresentOrElse(
            learner -> {
                System.out.print("Enter new full name (current: " + learner.getGivenName() + "): ");
                String newName = scanner.nextLine();
                System.out.print("Enter new email (current: " + learner.getContactEmail() + "): ");
                String newEmail = scanner.nextLine();
                learnerService.updateLearner(identifier, newName, newEmail);
                System.out.println("Learner updated successfully!");
            },
            () -> System.out.println("Learner not found.")
        );
    }
    
    private void deactivateLearner() {
        System.out.println("\n--- Deactivate Learner ---");
        System.out.print("Enter learner identifier to deactivate: ");
        String identifier = scanner.nextLine();
        learnerService.findLearnerByIdentifier(identifier).ifPresentOrElse(
            learner -> {
                learnerService.deactivateLearner(identifier);
                System.out.println("Learner deactivated successfully!");
            },
            () -> System.out.println("Learner not found.")
        );
    }
    
    private void enrollLearnerInModule() {
        System.out.println("\n--- Enroll Learner in Module ---");
        System.out.print("Enter learner identifier: ");
        String learnerId = scanner.nextLine();
        System.out.print("Enter module code: ");
        String moduleCode = scanner.nextLine();
        
        learnerService.findLearnerByIdentifier(learnerId).ifPresentOrElse(
            learner -> moduleService.findModuleByCode(moduleCode).ifPresentOrElse(
                module -> {
                    try {
                        learnerService.registerLearnerInModule(learnerId, module);
                        System.out.println("Enrollment successful!");
                    } catch (DuplicateRegistrationException | MaxUnitLimitExceededException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                },
                () -> System.out.println("Module not found.")
            ),
            () -> System.out.println("Learner not found.")
        );
    }
    
    private void manageLearnerGrades() {
        System.out.println("\n--- Manage Learner Grades ---");
        System.out.print("Enter learner identifier: ");
        String learnerId = scanner.nextLine();
        learnerService.findLearnerByIdentifier(learnerId).ifPresentOrElse(
            learner -> {
                System.out.println("Registered modules for " + learner.getGivenName() + ":");
                learner.getRegisteredModules().forEach(r -> System.out.println(r.getModule().getCode() + " - " + r.getModule().getTitle()));
                
                System.out.print("Enter module code to record grade for: ");
                String moduleCode = scanner.nextLine();
                
                learner.getRegisteredModules().stream()
                    .filter(r -> r.getModule().getCode().equals(moduleCode))
                    .findFirst()
                    .ifPresentOrElse(
                        registration -> {
                            System.out.print("Enter points (0-100): ");
                            try {
                                double points = scanner.nextDouble();
                                scanner.nextLine(); // Consume newline
                                registration.recordPoints(points);
                                System.out.println("Grade recorded successfully!");
                            } catch (InputMismatchException e) {
                                System.out.println("Invalid input. Please enter a number.");
                                scanner.nextLine();
                            }
                        },
                        () -> System.out.println("Learner is not registered in that module.")
                    );
            },
            () -> System.out.println("Learner not found.")
        );
    }

    private void printLearnerReport() {
        System.out.println("\n--- Academic Report ---");
        System.out.print("Enter learner identifier: ");
        String learnerId = scanner.nextLine();
        String report = learnerService.getAcademicReport(learnerId);
        System.out.println(report);
    }
    
    private void addNewModule() {
        System.out.println("\n--- Add New Module ---");
        System.out.print("Enter module code: ");
        String code = scanner.nextLine();
        System.out.print("Enter module title: ");
        String title = scanner.nextLine();
        System.out.print("Enter units: ");
        int units = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter instructor: ");
        String instructor = scanner.nextLine();
        System.out.print("Enter term (SPRING, SUMMER, FALL): ");
        Term term = Term.valueOf(scanner.nextLine().toUpperCase());
        System.out.print("Enter department: ");
        String department = scanner.nextLine();

        Module newModule = new Module.Builder(code, title)
            .units(units)
            .instructor(instructor)
            .term(term)
            .department(department)
            .build();
        moduleService.addModule(newModule);
        System.out.println("Module added successfully!");
    }
    
    private void listAllModules() {
        System.out.println("\n--- List All Modules ---");
        moduleService.listModules().forEach(System.out::println);
    }
    
    private void updateModule() {
        System.out.println("\n--- Update Module ---");
        System.out.print("Enter module code to update: ");
        String code = scanner.nextLine();
        moduleService.findModuleByCode(code).ifPresentOrElse(
            module -> {
                System.out.print("Enter new title (current: " + module.getTitle() + "): ");
                String newTitle = scanner.nextLine();
                System.out.print("Enter new units (current: " + module.getUnits() + "): ");
                int newUnits = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new instructor (current: " + module.getInstructor() + "): ");
                String newInstructor = scanner.nextLine();
                System.out.print("Enter new term (current: " + module.getTerm() + "): ");
                Term newTerm = Term.valueOf(scanner.nextLine().toUpperCase());
                System.out.print("Enter new department (current: " + module.getDepartment() + "): ");
                String newDepartment = scanner.nextLine();
                
                moduleService.updateModule(code, newTitle, newUnits, newInstructor, newTerm, newDepartment);
                System.out.println("Module updated successfully!");
            },
            () -> System.out.println("Module not found.")
        );
    }

    private void deactivateModule() {
        System.out.println("\n--- Deactivate Module ---");
        System.out.print("Enter module code to deactivate: ");
        String code = scanner.nextLine();
        moduleService.findModuleByCode(code).ifPresentOrElse(
            module -> {
                moduleService.deactivateModule(code);
                System.out.println("Module deactivated successfully!");
            },
            () -> System.out.println("Module not found.")
        );
    }
    
    private void searchModules() {
        System.out.println("\n--- Search Modules ---");
        System.out.println("1. By Instructor");
        System.out.println("2. By Department");
        System.out.println("3. By Term");
        System.out.print("Enter search option: ");
        try {
            int option = scanner.nextInt();
            scanner.nextLine();
            
            switch (option) {
                case 1:
                    System.out.print("Enter instructor name: ");
                    String instructor = scanner.nextLine();
                    moduleService.searchModulesByInstructor(instructor).forEach(System.out::println);
                    break;
                case 2:
                    System.out.print("Enter department name: ");
                    String department = scanner.nextLine();
                    moduleService.searchModulesByDepartment(department).forEach(System.out::println);
                    break;
                case 3:
                    System.out.print("Enter term (SPRING, SUMMER, FALL): ");
                    Term term = Term.valueOf(scanner.nextLine().toUpperCase());
                    moduleService.searchModulesByTerm(term).forEach(System.out::println);
                    break;
                default:
                    System.out.println("Invalid option.");
            }
        } catch (InputMismatchException | IllegalArgumentException e) {
            System.out.println("Invalid input or term. Please try again.");
            scanner.nextLine();
        }
    }
    
    private void importData() {
        System.out.println("\n--- Import Data ---");
        Path dataDir = AppCore.getInstance().getDataDirectory();
        
        try {
            System.out.println("Importing learners from learners.csv...");
            List<Learner> importedLearners = fileHandler.importLearnersFromCsv(dataDir.resolve("learners.csv"));
            importedLearners.forEach(learnerService::addLearner);
            System.out.println("Imported " + importedLearners.size() + " learners.");
            
            System.out.println("Importing modules from modules.csv...");
            List<Module> importedModules = fileHandler.importModulesFromCsv(dataDir.resolve("modules.csv"));
            importedModules.forEach(moduleService::addModule);
            System.out.println("Imported " + importedModules.size() + " modules.");
        } catch (IOException e) {
            System.err.println("Error importing files: " + e.getMessage());
        }
    }
    
    private void exportData() {
        System.out.println("\n--- Export Data ---");
        Path dataDir = AppCore.getInstance().getDataDirectory();
        
        try {
            fileHandler.exportLearnersToCsv(learnerService.listLearners(), dataDir.resolve("learners.csv"));
            fileHandler.exportModulesToCsv(moduleService.listModules(), dataDir.resolve("modules.csv"));
            System.out.println("Data exported successfully to " + dataDir.toAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error exporting files: " + e.getMessage());
        }
    }
    
    private void createBackup() {
        System.out.println("\n--- Create Backup ---");
        Path dataDir = AppCore.getInstance().getDataDirectory();
        Path backupDir = AppCore.getInstance().getDataDirectory().resolve("backups");
        
        try {
            Path backupPath = fileHandler.createBackup(dataDir, backupDir);
            System.out.println("Backup created at: " + backupPath.toAbsolutePath());
        } catch (IOException e) {
            System.err.println("Error creating backup: " + e.getMessage());
        }
    }
    
    private void listBackupSize() {
        System.out.println("\n--- Backup Size ---");
        Path backupDir = AppCore.getInstance().getDataDirectory().resolve("backups");
        try {
            long size = fileHandler.calculateDirectorySize(backupDir);
            System.out.println("Total size of backups: " + size + " bytes");
        } catch (IOException e) {
            System.err.println("Error calculating size: " + e.getMessage());
        }
    }

    private static void printMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Manage Learners");
        System.out.println("2. Manage Modules");
        System.out.println("3. File Operations");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }
    
    private static void printLearnerMenu() {
        System.out.println("\n--- Learner Management Menu ---");
        System.out.println("1. Add a new learner");
        System.out.println("2. List all learners");
        System.out.println("3. Update a learner");
        System.out.println("4. Deactivate a learner");
        System.out.println("5. Enroll in a module");
        System.out.println("6. Manage grades");
        System.out.println("7. View academic report");
        System.out.println("8. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }
    
    private static void printModuleMenu() {
        System.out.println("\n--- Module Management Menu ---");
        System.out.println("1. Add a new module");
        System.out.println("2. List all modules");
        System.out.println("3. Update a module");
        System.out.println("4. Deactivate a module");
        System.out.println("5. Search modules");
        System.out.println("6. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }
    
    private static void printFileMenu() {
        System.out.println("\n--- File Operations Menu ---");
        System.out.println("1. Import data");
        System.out.println("2. Export data");
        System.out.println("3. Create backup");
        System.out.println("4. Show backup size");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }
}