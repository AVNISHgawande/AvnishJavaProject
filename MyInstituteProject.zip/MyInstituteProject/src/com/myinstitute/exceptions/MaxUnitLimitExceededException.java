package com.myinstitute.exceptions;

public class MaxUnitLimitExceededException extends Exception {
    public MaxUnitLimitExceededException(String message) {
        super(message);
    }
}